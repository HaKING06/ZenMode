// =========================================
// ZENMODE v5.4 - SHORTS RESTORED
// =========================================
console.log("ZenMode v5.4: Shorts Panel Restored 📱");

// --- GLOBAL AYARLAR ---
let settings = { autoScroll: false };
let audioContext = null;
let lastUrl = location.href;

// --- 1. OTO-YENİLEME SİSTEMİ (F5 ETKİSİ) ---
function checkAndReload() {
    const urlParams = new URLSearchParams(window.location.search);
    const currentVideoId = urlParams.get('v');

    if (currentVideoId) {
        const lastVideoId = sessionStorage.getItem('zen_last_video');
        if (currentVideoId !== lastVideoId) {
            console.log("ZenMode: Yeni video -> Yenileniyor...");
            sessionStorage.setItem('zen_last_video', currentVideoId);
            location.reload();
        }
    }
}

// --- 2. AUDIO KEEPER (DİP SES) ---
function initAudioKeeper() {
    if (audioContext) return;
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioContext = new AudioContext();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        oscillator.type = 'sine'; oscillator.frequency.value = 20; 
        gainNode.gain.value = 0.00001;   
        oscillator.start();
        console.log("ZenMode: Audio Keeper Aktif.");
    } catch (e) {}
}
document.addEventListener('click', initAudioKeeper, { once: true });
document.addEventListener('keydown', initAudioKeeper, { once: true });


// --- 3. KALDIĞIN YERDEN DEVAM ---
function handleResume() {
    const video = document.querySelector('video');
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get('v');
    const savedTime = localStorage.getItem('zen_vid_' + videoId);
    
    if (video && videoId && savedTime && video.currentTime < 5) {
        const targetTime = parseFloat(savedTime);
        if (targetTime > 5) {
            video.currentTime = targetTime;
        }
    }
}

function saveProgress() {
    const video = document.querySelector('video');
    if (video && !video.paused && video.currentTime > 5) {
        const urlParams = new URLSearchParams(window.location.search);
        const vid = urlParams.get('v');
        if (vid) localStorage.setItem('zen_vid_' + vid, Math.floor(video.currentTime));
    }
}


// --- 4. REKLAM YÖNETİMİ ---
function killAds() {
    const video = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing');
    if (video && video.readyState < 2) return;

    if (adShowing && video) {
        video.playbackRate = 16.0; video.muted = true;
        const btns = document.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-overlay-close-button');
        btns.forEach(b => b.click());
    }
}


// --- 5. AMBILIGHT & SCREENSHOT ---
function manageAmbilight() {
    const v = document.querySelector('video');
    const c = document.querySelector('#movie_player');
    const isTheater = document.querySelector('ytd-watch-flexy[theater]');
    let cvs = document.getElementById('zen-ambilight-canvas');

    if (!isTheater || !v) { if (cvs) cvs.style.opacity = '0'; return; }
    if (!cvs && c) {
        cvs = document.createElement('canvas'); cvs.id = 'zen-ambilight-canvas'; 
        c.prepend(cvs); cvs.style.pointerEvents = 'none';
    }
    if (cvs && v && !v.paused) {
        cvs.style.opacity = '1';
        try {
            cvs.width = v.videoWidth * 0.1; cvs.height = v.videoHeight * 0.1;
            cvs.getContext('2d').drawImage(v, 0, 0, cvs.width, cvs.height);
        } catch(e) {}
    }
}

function takeScreenshot() {
    const v = document.querySelector('video'); if(!v) return;
    const c = document.createElement('canvas');
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
    let t = document.title.replace(/^\(\d+\)\s*/, '').replace(' - YouTube', '').trim().replace(/[<>:"/\\|?*]+/g, '').replace(/\s+/g, '_');
    const l = document.createElement('a');
    l.download = `${t}.png`; l.href = c.toDataURL('image/png'); l.click();
}

function injectScreenshotButton() {
    if (!window.location.href.includes('/watch')) return;
    const rc = document.querySelector('.ytp-right-controls');
    if (!rc || document.getElementById('zen-camera-btn')) return;

    if (!document.getElementById('zen-native-tooltip')) {
        const t = document.createElement('div'); t.id = 'zen-native-tooltip';
        t.innerHTML = 'Ekran Görüntüsü<span class="zen-key-box">S</span>';
        document.body.appendChild(t);
    }

    const b = document.createElement('button');
    b.id = 'zen-camera-btn'; b.className = 'zen-screenshot-btn ytp-button'; 
    b.innerHTML = `<svg height="24" viewBox="0 0 24 24" width="24" fill="none"><path d="M4 4h3l2-2h6l2 2h3c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2zm0 2v12h16V6h-2.6L15.55 4.1 15.25 4H8.75l-.3.1L6.6 6H4zm8 10c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#fff"/></svg>`;
    b.onclick = takeScreenshot;

    const tt = document.getElementById('zen-native-tooltip');
    b.onmouseenter = () => {
        const r = b.getBoundingClientRect();
        tt.style.display = 'block';
        tt.style.left = (r.left + r.width/2 - tt.offsetWidth/2) + 'px';
        tt.style.top = (r.top + window.scrollY - 48) + 'px';
        requestAnimationFrame(() => tt.classList.add('show'));
    };
    b.onmouseleave = () => { tt.classList.remove('show'); setTimeout(() => { if(!tt.classList.contains('show')) tt.style.display = 'none'; }, 100); };
    rc.insertBefore(b, rc.firstChild);
}

document.addEventListener('keydown', (e) => {
    if (window.location.href.includes('/watch') && e.key.toLowerCase() === 's' && document.activeElement.tagName !== 'INPUT') {
        e.preventDefault(); takeScreenshot();
    }
});


// --- 6. SHORTS YÖNETİMİ (GERİ GELDİ!) ---
function manageShortsPanel() {
    // Sadece Shorts sayfasındaysak çalış
    if (!window.location.href.includes('/shorts/')) {
        const p = document.getElementById('zen-shorts-panel'); 
        if(p) p.style.display = 'none'; 
        return;
    }

    // Panel yoksa oluştur
    if (!document.getElementById('zen-shorts-panel')) {
        const panel = document.createElement('div'); 
        panel.id = 'zen-shorts-panel';
        panel.innerHTML = `
            <div class="zen-label">Otomatik Akış</div>
            <div class="zen-switch">
                <input type="checkbox" id="zen-check">
                <span class="zen-slider"></span>
            </div>
        `;
        document.body.appendChild(panel);
        
        // Tıklama olayı
        const chk = document.getElementById('zen-check');
        panel.onclick = () => { 
            chk.checked = !chk.checked; 
            settings.autoScroll = chk.checked; 
        };
    } else { 
        document.getElementById('zen-shorts-panel').style.display = 'flex'; 
    }
}

function manageShortsLoop() {
    if (!settings.autoScroll || !window.location.href.includes('/shorts/')) return;
    
    const video = document.querySelector('video');
    // Video oynuyor, bitmek üzere ve aktifse
    if (video && !video.paused && video.duration > 0 && video.currentTime >= video.duration - 0.4) {
        // Aşağı kaydırma butonunu bul ve tıkla
        const nextBtn = document.getElementById('navigation-button-down')?.querySelector('button');
        if(nextBtn) {
            nextBtn.click(); 
        } else {
            // Buton yoksa klavye yön tuşu gönder
            document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, bubbles: true }));
        }
    }
}


// --- ANA DÖNGÜ ---
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        checkAndReload(); 
    }
}).observe(document, {subtree: true, childList: true});

setInterval(() => {
    killAds();
    manageAmbilight();
    injectScreenshotButton();
    
    // Shorts Fonksiyonları Döngüye Eklendi
    manageShortsPanel();
    manageShortsLoop();
    
    saveProgress();
}, 80);

window.addEventListener('load', () => {
    checkAndReload();
    setTimeout(() => {
        handleResume();
        const v = document.querySelector('video');
        if(v) v.focus();
    }, 600);
});