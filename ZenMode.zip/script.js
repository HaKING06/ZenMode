// =========================================
// ZENMODE v4.3 - ULTRA NATIVE
// =========================================
console.log("ZenMode v4.3: Native Tooltip 📸");

let settings = { autoScroll: false };
let ambilightInterval = null;

// --- REKLAM ---
function killAds() {
    const video = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing');
    if (adShowing && video) {
        video.playbackRate = 16.0; video.muted = true;
        document.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern').forEach(b => b.click());
        const overlay = document.querySelector('.ytp-ad-overlay-close-button');
        if (overlay) overlay.click();
    }
}

// --- AMBILIGHT ---
function manageAmbilight() {
    const app = document.querySelector('ytd-watch-flexy');
    const video = document.querySelector('video');
    const player = document.querySelector('#movie_player');
    let canvas = document.getElementById('zen-ambilight-canvas');
    const isTheaterMode = app && app.hasAttribute('theater');
    if (!isTheaterMode || !video) { if (canvas) canvas.style.opacity = '0'; return; }
    if (!canvas && player) {
        canvas = document.createElement('canvas'); canvas.id = 'zen-ambilight-canvas'; player.prepend(canvas);
    }
    if (canvas) {
        canvas.style.opacity = '1';
        if (!ambilightInterval) {
            const ctx = canvas.getContext('2d');
            ambilightInterval = setInterval(() => {
                if (video.paused || !document.querySelector('ytd-watch-flexy[theater]')) return;
                canvas.width = video.videoWidth * 0.1; canvas.height = video.videoHeight * 0.1;
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            }, 60);
        }
    }
}

// --- SCREENSHOT ---
function takeScreenshot() {
    const video = document.querySelector('video');
    if (!video) return;
    const flash = document.createElement('div');
    Object.assign(flash.style, { position: 'fixed', inset: '0', background: 'white', opacity: '0.4', zIndex: '999999', pointerEvents: 'none', transition: 'opacity 0.2s' });
    document.body.appendChild(flash);
    setTimeout(() => { flash.style.opacity = '0'; setTimeout(() => flash.remove(), 200); }, 50);

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    
    let title = document.title.replace(/^\(\d+\)\s*/, '').replace(' - YouTube', '').trim();
    title = title.replace(/[<>:"/\\|?*]+/g, '').replace(/\s+/g, '_');
    const ct = video.currentTime;
    const hh = Math.floor(ct / 3600);
    const mm = Math.floor((ct % 3600) / 60).toString().padStart(2, '0');
    const ss = Math.floor(ct % 60).toString().padStart(2, '0');
    const timeStr = hh > 0 ? `${hh}.${mm}.${ss}` : `${mm}.${ss}`;
    const filename = `${title}_${timeStr}.png`;

    const link = document.createElement('a');
    link.download = filename; link.href = canvas.toDataURL('image/png'); link.click();
}

// --- TOOLTIP YARATICI ---
function createTooltip() {
    if (document.getElementById('zen-native-tooltip')) return;
    const tooltip = document.createElement('div');
    tooltip.id = 'zen-native-tooltip';
    
    // BURASI ÖNEMLİ: Görseldeki gibi "S" harfini kutu içine alıyoruz
    tooltip.innerHTML = 'Ekran Görüntüsü<span class="zen-key-box">S</span>';
    
    document.body.appendChild(tooltip);
}

// --- BUTON ---
function injectScreenshotButton() {
    if (!window.location.href.includes('/watch')) return;
    const rightControls = document.querySelector('.ytp-right-controls');
    if (!rightControls || document.getElementById('zen-camera-btn')) return;

    createTooltip();

    const btn = document.createElement('button');
    btn.id = 'zen-camera-btn';
    btn.className = 'zen-screenshot-btn ytp-button'; 
    
    // GÜNCEL KAMERA İKONU
    btn.innerHTML = `
        <svg height="24" viewBox="0 0 24 24" width="24" fill="none">
             <path d="M4 4h3l2-2h6l2 2h3c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2zm0 2v12h16V6h-2.6L15.55 4.1 15.25 4H8.75l-.3.1L6.6 6H4zm8 10c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#fff"/>
        </svg>
    `;
    
    btn.onclick = takeScreenshot;

    // --- TOOLTIP POZİSYONLAMA ---
    const tooltip = document.getElementById('zen-native-tooltip');

    btn.onmouseenter = () => {
        if (!tooltip) return;
        const rect = btn.getBoundingClientRect();
        
        tooltip.style.display = 'block';
        
        const leftPos = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2);
        // Butonun tepesinden 48px yukarı
        const topPos = rect.top + window.scrollY - 48; 

        tooltip.style.left = `${leftPos}px`;
        tooltip.style.top = `${topPos}px`;
        
        requestAnimationFrame(() => tooltip.classList.add('show'));
    };

    btn.onmouseleave = () => {
        if (!tooltip) return;
        tooltip.classList.remove('show');
        setTimeout(() => { if(!tooltip.classList.contains('show')) tooltip.style.display = 'none'; }, 100);
    };

    rightControls.insertBefore(btn, rightControls.firstChild);
}

// KLAVYE KISAYOLU (S)
document.addEventListener('keydown', (e) => {
    if (window.location.href.includes('/watch') && (e.key.toLowerCase() === 's')) {
        const tag = document.activeElement.tagName.toLowerCase();
        if (tag === 'input' || tag === 'textarea' || document.activeElement.isContentEditable) return;
        e.preventDefault();
        takeScreenshot();
    }
});

function manageShortsPanel() {
    if (!window.location.href.includes('/shorts/')) {
        const p = document.getElementById('zen-shorts-panel'); if(p) p.style.display = 'none'; return;
    }
    if (!document.getElementById('zen-shorts-panel')) {
        const panel = document.createElement('div'); panel.id = 'zen-shorts-panel';
        panel.innerHTML = `<div class="zen-label">Otomatik Akış</div><div class="zen-switch"><input type="checkbox" id="zen-check"><span class="zen-slider"></span></div>`;
        document.body.appendChild(panel);
        const chk = document.getElementById('zen-check');
        panel.onclick = () => { chk.checked = !chk.checked; settings.autoScroll = chk.checked; };
    } else { document.getElementById('zen-shorts-panel').style.display = 'flex'; }
}
function manageShortsLoop() {
    if (!settings.autoScroll || !window.location.href.includes('/shorts/')) return;
    const videos = document.querySelectorAll('video'); let activeVideo = null;
    videos.forEach(v => { if (!v.paused && v.duration > 0) activeVideo = v; });
    if (activeVideo && activeVideo.currentTime >= activeVideo.duration - 0.4) {
        const nextBtn = document.getElementById('navigation-button-down')?.querySelector('button');
        if(nextBtn) nextBtn.click(); else document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, bubbles: true }));
    }
}

setInterval(() => { killAds(); manageAmbilight(); injectScreenshotButton(); manageShortsPanel(); manageShortsLoop(); }, 100);