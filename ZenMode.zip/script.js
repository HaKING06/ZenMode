// ZenMode: Ad Speed-Hack & Auto Skipper 🚀
console.log("ZenMode: Aktif! Reklamlara acımak yok.");

// Reklam Avcısı Fonksiyonu
function killAds() {
    // 1. Video Player'ı Bul
    const video = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing'); // Reklam oynuyor mu?

    if (adShowing && video) {
        // --- TAKTİK: IŞINLAMA ---
        // YouTube reklamın izlendiğini sanması için hızı sona dayıyoruz
        video.playbackRate = 16.0; 
        video.muted = true; // Ciyaklama duymamak için sesi kes

        // Eğer video çok uzunsa direkt sonuna sar (Bazen player'ı bozabilir diye kontrol şart)
        if(video.currentTime < video.duration - 0.5) {
            video.currentTime = video.duration; 
        }

        console.log("ZenMode: Reklam ışınlandı! ⚡");

        // --- TAKTİK: TIKLAMA ---
        // Klasik atla butonları
        const skipButtons = [
            '.ytp-ad-skip-button',
            '.ytp-ad-skip-button-modern',
            '.videoAdUiSkipButton'
        ];

        skipButtons.forEach(selector => {
            const btn = document.querySelector(selector);
            if (btn) {
                btn.click();
                console.log("ZenMode: Butona tıklandı! 👆");
            }
        });
    }

    // 2. Banner Reklamları (Videounun altındaki çarpılı kutucuklar)
    const overlayButton = document.querySelector('.ytp-ad-overlay-close-button');
    if (overlayButton) {
        overlayButton.click();
    }
}

// Bu fonksiyonu sürekli çalıştır (Her 50 milisaniyede bir kontrol et)
// Observer yerine Interval kullanıyoruz çünkü video hızı anlık değişmeli
setInterval(killAds, 50);